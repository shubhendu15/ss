python train.py --model rkccsnet --sensing-rate 0.5 --epochs 200 --batch-size 4\
                  --block-size 32 --image-size 96 --lr 1e-3 --save-dir save_temp 